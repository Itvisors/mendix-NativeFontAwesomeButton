//>>built
define("dijit/nls/de/loading",({loadingState:"Wird geladen...",errorState:"Es ist ein Fehler aufgetreten."}));
