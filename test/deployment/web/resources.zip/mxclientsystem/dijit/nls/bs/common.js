//>>built
define("dijit/nls/bs/common",{buttonOk:"OK",buttonCancel:"Odustani",buttonSave:"Spremi",itemClose:"Zatvori"});
